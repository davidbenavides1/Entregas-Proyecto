import dash
import dash_core_components as dcc
import dash_html_components as html
import pandas as pd
import numpy as np
import plotly.express as px
import seaborn as sns
import datetime as dt
from datetime import datetime
import matplotlib as cm
import matplotlib.pyplot as plt
import plotly.graph_objects as go
from dash.dependencies import Input, Output
import seaborn as sns
import plotly.graph_objects as go

##Importar datos

#app = dash.Dash(__name__)

external_stylesheets = ['https://codepen.io/chriddyp/pen/bWLwgP.css']
app = dash.Dash(__name__, external_stylesheets=external_stylesheets)

datos = pd.read_csv('database.csv', 
                 sep = ';',
                 index_col=0,
                 )
datos1=datos
datos2=datos1[datos1.iloc[:,21]!=0]
datos2=datos2[datos2.iloc[:,22]!=0]
datos2=datos2[datos2.iloc[:,15]!=0]
datos2=datos2[datos2.iloc[:,15]!=1]
datos2=datos2[datos2.iloc[:,15]!=2]
datos2=datos2[datos2.iloc[:,15]!=3]
datos2=datos2[datos2.iloc[:,15]!=4]
datos2=datos2[datos2.iloc[:,15]!=5]
datos2=datos2[datos2.iloc[:,15]!=6]
datos2=datos2[datos2.iloc[:,15]!=7]
datos2=datos2[datos2.iloc[:,15]!=8]
datos2=datos2[datos2.iloc[:,15]!=9]
datos2.iloc[:,19].replace({"Girlfriend":"Boyfriend/Girlfriend","Boyfriend":"Boyfriend/Girlfriend"},inplace=True)
datos2=datos2[datos2['Victim Sex']!="Unknown"]
datos2=datos2[datos2['Victim Age']!=998]
datos22=datos2
bins = [-1, 4, 11, 17,28, 38,48,58, 102]
names = ["0 a 5 años", "06 a 11 años", "12 a 17 años", "18 a 29 años", "30 a 39 años", "40 a 49 años","50 a 59 años","Más de 60 años"]
datos22['Rango_E_V']=pd.cut(datos22['Victim Age'], bins, labels = names)

datos2=datos2[datos2['Victim Count']!= 0]
datos3=datos2
datos3=datos3.iloc[:,1:24]

State = datos2['State'].unique()
State=np.append(State,"USA")
Year=datos2['Year'].unique()


## Visualización 2 David
temp=pd.crosstab(datos22['Month'],datos22['Year'])
temp=temp.reindex(index=['January','February','March','April','May','June','July','August','September','October','November','December'])
fig2=px.line(temp,x=temp.index, y=temp.columns)

State1=datos3['State'].unique()
datos3['Weapon'].replace({"Gun":"Pistola","Handgun":"Pistola","Firearm":"Arma de fuego","Shotgun":"Rifle","Gun":"Pistola",
                         "Knife":"Cuchillo","Blunt Object":"Objeto desafilado","Explosives":"Eplosivos",
                         "Strangulation":"Sofocado","Drowning":"Sofocado","Poison":"Veneno","Drugs":"Veneno",
                         "Suffocation":"Sofocado","Fire":"Fuego", "Unknown":"Desconocido","Fall":"Desconocido"},inplace=True)

## Filtros
tipo_crimen = datos2['Perpetrator Race'].unique()
tipo_crimen = datos2['Crime Type'].unique()



app.layout = html.Div([
    html.H1("Proyecto entrega final"),
    html.H2("Descripción y limpieza de datos"),
    html.Div(children='''
        Los datos fueron extraídos de la página de datos públicos Kaggle, el contexto de la base corresponde a los homicidios 
        reportados en Estados Unidos desde el 1980 al 2014, la base contiene los datos de ocurrencia del asesinato como 
        la ubicación (estado y ciudad), el mes y año de la ocurrencia, el hecho de que los crímenes fueron resueltos,el tipo del crimen, 
        datos sobre la victima como su edad, sexo, raza, etnia y cantidad, y las mismas aplican para los perpetradores 
        añadiendo su relación con su víctima y el arma utilizada.
    '''),
    html.Div(children='''
        En cuanto a la limpieza de los datos no se encontraron datos faltantes, pero de los datos que estaban presentes se depuraron 
        de las variables número de perpetradores y numero de victimas que eran igual 0, de la variable edad de los perpetradores 
        se depuraron aquellos que fueran menores o iguales a 9, de la variable sexo de la victima se eliminan los desconocidos, 
        en la edad de la víctima se eliminó un dato atípico que era igual a 998. Se creo una variable nueva de rangos de edad de 
        la víctima.
    '''),
    html.H2("Visualizaciones David Benavides"),
    html.Div([
        html.Div([
            html.H3("Visualización 1"),
               html.Div(children='''
                   (What?)Las variables que se escogieron para la visualización son variables de tipo categóricas las cuales son las variables 
                   rango de edad de la victima y la otra variable es el sexo de la víctima, con el fin de relacionar las variables se elaboro 
                   una tabla de contingencias con el fin de contar las frecuencias de las 2 variables en cada categoría y así elaborar el mapa 
                   de color.(Why?)Relacionar categorías entre las variables genero de la victima y rango de edad de la victima con el fin de 
                   encontrar las frecuencias de las variables en cada categoría de ambas variables, para así descubrir relaciones posibles 
                   entre las categorías y observar que tantos individuos son más frecuentes en la clasificación de ambas variables.
                   (How?)Las interacciones para esta visualización son necesarias para examinar de manera más profunda la información general, 
                   siendo que se aplica el filtro para un análisis de dominios que son los estados y para un análisis evolutivo de la cantidad 
                   de homicidios a través del tiempo, se encuentra el slider que sirve para observar la acumulación de casos en el mapa de calor.
               '''),
               dcc.Dropdown(
                   id='demo-dropdown',
                   options=[{'label': i, 'value': i} for i in State],
                   value='USA'
               ),  
        
               dcc.Graph(
                   id='V1'
               ),
               dcc.Slider(
               id='year',
               min=min(datos2['Year']),
               max=max(datos2['Year']),
               step=1,
               marks={i: '{}'.format(i) for i in range(1980,2014)} 
               ),   

            ] ),
        
        html.Div([
            html.H3("Visualización 2"),
            html.Div(children='''
                (What?)Los datos que el usuario puede encontrar en este gráfico son diferentes líneas que representan la cantidad de casos 
                de homicidios de cada año entre los años 1980 y 2014, esta visualización lineal tiene en el eje X los 12 meses del año y 
                la cuenta de homicidios de cada mes está en el eje Y.(Why?)Identificar diferencias en cada uno de los años entre 1980 y 2014, 
                cada año al ser representado con una línea diferente tiene el objetivo de que a través de los meses el usuario pueda observar 
                la evolución de la cantidad y comparar así cada mes de un año con el mismo mes de otro año.(How?)El usuario requiere interactuar 
                con la visualización debido a que al ser demasiados años en los datos el usuario puede presentar dificultades al identificar 
                los diferentes colores que hay para cada año, por lo que existe la libertad de que se puede elegir cuantos y cuales años ver 
                en el diagrama.
            '''),       

            dcc.Graph(
                id='V2',
                figure=fig2
            ),  

        ]), 
    
    ],className="row"),


    html.Div([
        html.Div([  
             html.H2("Visualizaciones Luz Rodriguez"),
                html.H3("Visualización 3"),
                    html.Div(
                        dcc.Markdown('''
                    
                        - ¿What?    

                        Para la visualización treemaps propuesta se utilizaron las variables categóricas arma, que nos da la información del tipo del
                        arma con el que se cometio el homicidio y Estado, la cual nos da el estado en donde se cometio el homicidio, también se utilizaron
                        las variables númericas año en el que se registro el homicidio y el numero de incidentes de homicidio reportados. El gráfico 
                        se elaboro con el fin de observar que armas fueron las mas usadas para cometer los homicidios, en la visualización se podrá 
                        observar para cada arma los estados en que mas se han utilizado, ademas de poder observar, el total de incidentes cometidos con 
                        ese tipo de arma. El datase es de tipo tabla con datos estáticos, ya que cuenta con atributos de las cuales 2 son variables categoricas
                        y 2 son variables cuantitativa, también cuenta con ítems que representan los registros por cada caso de homicidio.       

                        - Why?    

                        La gráfica compara, ya que el propósito de la gráfica es mostrar el que armas son las mas utilizadas por los perpetradores
                        al momento de cometer un homicidio, en los diferentes estados y ciudades de Estados Unidos, algunos de los analsisi que se pudo 
                        observar es que las armas mas populares para el año 1980 el cual es el año base, fueron las pistolas, cuchillos, rifles y fuego
                        en donde destacaban los estados de California, Texas, Illinois y New York, cabe aclarar que este resultado el cual pertenece al año
                        1980 es uno entre los 35 años en los que se podra obtener el mismo tipo de información.   
         

                        - How?    

                        Son pertienentes las interacciones en este gráfico ya que le facilita al usuario observar y comparar que armas son las mas utilizadas
                        en los diferentes estados y ciudades por los perpetradores para cometer homicidio, ademas al mismo tiempo tambien es posible observar
                        el numero de indidentes cometidos tanto en la ciudades como en el estado por lo que brinda información muy completa, además se podran 
                        hacer comparaciones entre los años para mirar como ha cambiado el tipo de armas más utilizadas    

                        '''
                     )
                ),
                dcc.Dropdown(
                    id='demo-dropdown2',
                    options=[{'label': i, 'value': i} for i in State1],
                    multi=True,
                    value=['Arizona','California']    
                ),
                dcc.Graph(
                    id='V3'
                ),
                dcc.Checklist(
                    id='year2',
                    options=[{'label': i, 'value': i} for i in Year],
                    value=['1980'],
                    labelStyle={'display': 'inline-block'}
                ),
        ], className='six columns'),
        html.Div([  
                html.H3("Visualización 4"),
                    html.Div(
                        dcc.Markdown('''
                    
                        - ¿What?    

                        Las variables que se ven representadas en la visualización son variables de tipo categóricas y numericas, la varaiables 
                        categoricas utilizadas son: Estado, la cual nos el estado en donde cometio el homicidio y ciudad la cual no da la ciudad
                        perteneciente al estado donde se cometio el crimen, las variables numericas son: edad de la victima de homicidio y el numero 
                        de victimas que nos indica el número de víctimas en el homicidio para el año correspondiente. El gráfico de sunburst charts 
                        se elaboro con el fin de observar el total de numero de victimas por ciudad y asi mismo por estado, ademas de poder observar
                        la edad promedio de de las victimas de asesinato. El datase es de tipo tabla con datos estáticos, ya que cuenta con atributos 
                        de las cuales 2 son variables categoricas y 2 son variables cuantitativa, cuenta con ítems que representan los registros por 
                        cada caso de homicidio.       

                        - Why?    

                        La gráfica compara y presenta, ya que el propósito de la gráfica es mostrar y comparar el numero de casos de victimias 
                        de homicidios anuales por estado y ciudad para los años desde 1980 a 2014, que como se puede observar el número de víctimas 
                        para 1980 en el estado de Alabama fue de 6 mientras que Arizna que fue de 2, estas comparaciones pueden realizarse para tdos 
                        los estados y ciudades además de poder obtener el acumlado de victimas por cada año que se le agregue.   
         

                        - How?    

                        Son pertienentes las interacciones en este gráfico ya que le facilita al usuario observar, encontrar y comparar en numero de 
                        victimas que se han registrado en las ciudades para cada estado, ademas al mismo tiempo tambien es posible observar que edades 
                        tenian las victimasen  el momento del homicidio, de este modo se pueden generar comparaciones entre estados, ciudades o hasta 
                        en años, ya que la visualización tambíen permite ver año a año el numero de victimas o en su defecto observar la suma del total
                        de victimas para los años deseados.    

                        '''
                     )
                ),
                dcc.Checklist(
                    id='year3',
                    options=[{'label': i, 'value': i} for i in Year],
                    value=[1980],
                    labelStyle={'display': 'inline-block'}
                ),
                dcc.Graph(
                    id='V4'
                )
        ], className='six columns'), 
    ], className='row'),#   
])

#Viz 1

@app.callback(
    dash.dependencies.Output('V1', 'figure'),
    [dash.dependencies.Input('year', 'value'),
    dash.dependencies.Input('demo-dropdown', 'value')]
    )


    
def Espacial(año,estado):
    datos3=datos22[datos22['Year']<=año]
    if estado=="USA":
        base = datos3
        query = pd.crosstab(index=base["Rango_E_V"],columns=base["Victim Sex"])
    else:
        base = datos3[datos3['State']==str(estado)]
        query = pd.crosstab(index=base["Rango_E_V"],columns=base["Victim Sex"])

    fig = px.imshow(query,
            color_continuous_scale="reds")
    return(fig)


#Viz 3

@app.callback(
    dash.dependencies.Output('V3', 'figure'),
    [dash.dependencies.Input('year2', 'value'),
    dash.dependencies.Input('demo-dropdown2', 'value')]
    )
    
def Espacial3(año,estado):
    año1=[]
    año1=np.append(año1,año)
    estado1=[]
    estado1=np.append(estado1,estado)
    df = datos3[(datos3['Year'].isin(año1)) & (datos2['State'].isin(estado1))]
    fig3 = px.sunburst(df, path=['State', 'City'], values='Victim Count',
                  color='Victim Age')
    año1=[]
    estado1=[]
    return(fig3)

#Viz 4

@app.callback(
    dash.dependencies.Output('V4', 'figure'),
    [dash.dependencies.Input('year3', 'value')]
    )
    
def Espacial4(año):
    df = datos3[ (datos3['Year'].isin(año))]
    fig4 = px.treemap(df, path=[px.Constant('Armas'),'Weapon', 'State'], values='Incident')
    
    return(fig4)

    
if __name__ == "__main__":
    app.run_server(debug=True)
